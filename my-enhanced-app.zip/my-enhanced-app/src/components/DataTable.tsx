import React, { useState, useMemo, useCallback, useContext } from 'react';
import { DataContext, DataItem } from '../contexts/DataContext'; // Import context
import styles from './DataTable.module.css'; // Import CSS Module

const PAGE_SIZE = 10; // Records per page

// Define sort direction type
type SortDirection = 'asc' | 'desc';

interface SortConfig {
  key: string | null;
  direction: SortDirection | null;
}

const DataTable: React.FC = () => {
  // Consume state and setters from context
  const { data, loading, error, filters, setFilters, groupBy, setGroupBy, allColumns } = useContext(DataContext);

  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: null, direction: null });
  const [currentPage, setCurrentPage] = useState(1);

  // Available columns for filtering/grouping (exclude maybe an 'id' if not useful)
  const availableColumns = useMemo(() => allColumns.filter(col => col !== 'id'), [allColumns]);

  // Memoized calculation for filtered data count (before pagination)
  const filteredDataCount = useMemo(() => {
    if (!data) return 0;
     return data.filter((item) =>
      Object.entries(filters).every(([key, filterValue]) => {
        if (!filterValue) return true;
        const itemValue = item[key];
        return itemValue !== null && itemValue !== undefined &&
               itemValue.toString().toLowerCase().includes(filterValue.toLowerCase());
      })
    ).length;
  }, [data, filters]);

  // Memoized processing: Filtering, Sorting, Pagination
  const processedData = useMemo(() => {
    if (!data || data.length === 0) return [];

    // 1. Apply Filters from context
    let filtered = data.filter((item) =>
      Object.entries(filters).every(([key, filterValue]) => {
        if (!filterValue) return true;
        const itemValue = item[key];
        return itemValue !== null && itemValue !== undefined &&
               itemValue.toString().toLowerCase().includes(filterValue.toLowerCase());
      })
    );

    // 2. Apply Sorting
    if (sortConfig.key && sortConfig.direction) {
      const { key, direction } = sortConfig;
      // Create a copy before sorting to avoid mutating the filtered array directly
      filtered = [...filtered].sort((a, b) => {
        const aValue = a[key];
        const bValue = b[key];

        // Basic type-aware comparison
        if (aValue === null || aValue === undefined) return direction === 'asc' ? 1 : -1;
        if (bValue === null || bValue === undefined) return direction === 'asc' ? -1 : 1;

        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return direction === 'asc' ? aValue - bValue : bValue - aValue;
        }

        // Default to string comparison
        const aStr = aValue.toString();
        const bStr = bValue.toString();
        return direction === 'asc' ? aStr.localeCompare(bStr) : bStr.localeCompare(aStr);
      });
    }

    // 3. Apply Pagination
    const startIndex = (currentPage - 1) * PAGE_SIZE;
    return filtered.slice(startIndex, startIndex + PAGE_SIZE);

  }, [data, filters, sortConfig, currentPage]); // Re-run when these dependencies change

  // --- Event Handlers ---

  const handleSort = useCallback((key: string) => {
    setSortConfig((prev) => {
      const isAsc = prev.key === key && prev.direction === 'asc';
      return { key, direction: isAsc ? 'desc' : 'asc' };
    });
    // Optional: Reset to page 1 on sort
    // setCurrentPage(1);
  }, []);

  const handleFilterChange = useCallback((key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setCurrentPage(1); // Reset to page 1 when filters change
  }, [setFilters]);

  const handleGroupByChange = useCallback((key: string) => {
    setGroupBy((prev) =>
      prev.includes(key)
        ? prev.filter((k) => k !== key)
        : [...prev, key]
    );
  }, [setGroupBy]);

  // --- Pagination Logic ---
  const totalPages = Math.ceil(filteredDataCount / PAGE_SIZE);

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  // --- Rendering ---

  // Show loading/error states consistent with Graph
  if (loading) return <div className={styles.loading}>Loading Table Data...</div>;
  // Error state is handled by context consumer in App.tsx usually, but can add specific message here too
  if (error && data.length === 0) return <div className={styles.errorMessage} role="alert">Error loading table: {error}</div>;
  if (!data || data.length === 0) return <div className={styles.errorMessage} role="alert">No data available</div>;

  return (
    <div className={styles.tableContainer}>
      {/* Controls - Group By and Filter */}
      <div className={styles.controlGroup} role="toolbar" aria-label="Table Controls">
        <div className={styles.controlItem}>
          <label>Filter By:</label>
          <div className={styles.optionsContainer}>
            {availableColumns.map((col) => (
              <input
                key={`filter-${col}`}
                type="text"
                className={styles.filterInput}
                placeholder={`Filter ${col}...`}
                value={filters[col] || ''}
                onChange={(e) => handleFilterChange(col, e.target.value)}
                aria-label={`Filter by ${col}`}
              />
            ))}
          </div>
        </div>
        <div className={styles.controlItem}>
          <label>Group By (for Chart):</label>
          <div className={styles.optionsContainer}>
            {availableColumns.map((col) => (
              <label key={`group-${col}`} className={styles.groupByLabel}>
                <input
                  type="checkbox"
                  value={col}
                  checked={groupBy.includes(col)}
                  onChange={() => handleGroupByChange(col)}
                  aria-label={`Group chart data by ${col}`}
                />
                {col}
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* Data Table */}
      <table className={styles.dataTable} role="grid" aria-label="Data Table">
        <thead>
          <tr>
            {allColumns.map((col) => (
              <th
                key={col}
                onClick={() => handleSort(col)}
                role="columnheader"
                aria-sort={
                  sortConfig.key === col
                    ? sortConfig.direction === 'asc' ? 'ascending' : 'descending'
                    : 'none'
                }
                tabIndex={0} // Make header focusable
                onKeyDown={(e) => e.key === 'Enter' && handleSort(col)} // Allow sorting with Enter key
              >
                {col}
                {/* Visual sort indicator */}
                <span className={styles.sortIcon}>
                  {sortConfig.key === col
                    ? sortConfig.direction === 'asc' ? '▲' : '▼'
                    : '' // Optionally show a default '↕' icon when not sorted
                  }
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {processedData.length === 0 ? (
            <tr>
              <td colSpan={allColumns.length} className={styles.noDataCell}>
                {filteredDataCount === 0 && Object.values(filters).some(v => v)
                 ? 'No data matches the current filters.'
                 : 'No data available.'}
              </td>
            </tr>
          ) : (
            processedData.map((row, index) => (
              // Use a unique ID from the data if available, otherwise fallback to index
              <tr key={row.id ?? `row-${index}`}>
                {allColumns.map((col) => (
                  <td key={col}>{row[col] ?? '-'}</td> // Display '-' for null/undefined
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>

      {/* Pagination Controls */}
      {totalPages > 1 && (
         <div className={styles.pagination} role="navigation" aria-label="Table Pagination">
           <button
             onClick={() => goToPage(currentPage - 1)}
             disabled={currentPage === 1}
             aria-label="Go to previous page"
           >
             « Previous
           </button>
           <span className={styles.pageInfo} aria-label={`Page ${currentPage} of ${totalPages}`}>
             Page {currentPage} of {totalPages} (Total: {filteredDataCount})
           </span>
           <button
             onClick={() => goToPage(currentPage + 1)}
             disabled={currentPage === totalPages}
             aria-label="Go to next page"
           >
             Next »
           </button>
         </div>
      )}
    </div>
  );
};

export default DataTable;
