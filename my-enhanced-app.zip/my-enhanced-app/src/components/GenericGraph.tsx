import React, { useState, useMemo, useCallback, useRef, useContext, MouseEvent } from 'react'; // Keep only this line
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, RadialLinearScale, Tooltip, Legend, Title, // Added Title
  ChartType, ChartData, ChartOptions, InteractionMode, ChartEvent, ActiveElement, LegendItem, LegendElement, // More specific types, Added LegendItem, LegendElement
} from 'chart.js';
import { Chart, getElementAtEvent } from 'react-chartjs-2'; // Use generic Chart component for flexibility
import { DataContext, DataItem } from '../contexts/DataContext'; // Import context
import styles from './GenericGraph.module.css'; // Import CSS Module

// Register necessary Chart.js components
ChartJS.register(
  CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, RadialLinearScale, Tooltip, Legend, Title
);

// Define supported chart types explicitly
const chartTypes = [
  'bar', 'line', 'pie', 'doughnut', 'polarArea', 'radar',
  'bubble', 'scatter', 'stackedBar', 'horizontalBar', 'area', 'stackedArea',
  // 'mixed', // Keep mixed simpler for now, handle via datasetTypes prop
] as const; // Use 'as const' for stricter typing
type SupportedChartType = typeof chartTypes[number];

// Define default colors (can be expanded)
const defaultColors = [
  '#36A2EB', '#FF6384', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40',
  '#E7E9ED', '#8399A5', '#C9CBCF'
];

// --- Helper Functions ---

// Basic Aggregators
const aggregators: Record<string, (items: DataItem[], key: string) => number> = {
  sum: (items, key) => items.reduce((sum, item) => sum + (Number(item[key]) || 0), 0),
  avg: (items, key) => {
    const sum = items.reduce((sum, item) => sum + (Number(item[key]) || 0), 0);
    const count = items.filter(item => item[key] !== null && item[key] !== undefined).length;
    return count > 0 ? sum / count : 0;
  },
  count: (items) => items.length,
  // Add more aggregators as needed (min, max, median, etc.)
};

// Improved Grouping Function
const groupByKeys = (data: DataItem[], keys: string[]): Record<string, DataItem[]> => {
  if (!keys || keys.length === 0) {
    return { 'all_data': data }; // Return all data under a single key if no grouping
  }
  const result: Record<string, DataItem[]> = {};
  data.forEach((item) => {
    // Create a composite key, handling potential null/undefined values
    const key = keys.map((k) => item[k] ?? 'Unknown').join(' | ');
    if (!result[key]) {
      result[key] = [];
    }
    result[key].push(item);
  });
  return result;
};


// --- Component Props ---

interface GenericGraphProps {
  // Required props for basic chart definition
  xLabelKey: string; // Key in data objects for X-axis labels/values
  yLabelKey: string; // Key in data objects for Y-axis values

  // Optional customization props
  initialGraphType?: SupportedChartType;
  title?: string; // Optional chart title
  datasetTypes?: Array<{ label: string; type: ChartType }>; // For mixed charts
  aggregator?: keyof typeof aggregators | ((items: DataItem[], key: string) => number);
  colors?: string[];
  customOptions?: Partial<ChartOptions>; // Allow deep merging of options
  onChartClick?: (event: ChartEvent, elements: ActiveElement[], chart: ChartJS) => void;
}

// --- Component Implementation ---

const GenericGraph: React.FC<GenericGraphProps> = ({
  xLabelKey,
  yLabelKey,
  initialGraphType = 'bar',
  title,
  datasetTypes = [], // Not fully implemented in processing logic below, but prop exists
  aggregator = 'sum',
  colors = defaultColors,
  customOptions = {},
  onChartClick,
}) => {
  const { data, loading, error, filters, groupBy: selectedGroupBy, allColumns } = useContext(DataContext); // Consume context
  const [graphType, setGraphType] = useState<SupportedChartType>(initialGraphType);
  const [visibleDatasets, setVisibleDatasets] = useState<Record<string, boolean>>({}); // Track legend clicks
  const chartRef = useRef<ChartJS | null>(null); // More specific type

  // --- Validation ---
  const validationError = useMemo(() => {
    if (loading || error) return null; // Handled by context states
    if (!data || data.length === 0) return 'No data available to display.';
    if (!xLabelKey || !allColumns.includes(xLabelKey)) return `Invalid xLabelKey: "${xLabelKey}". Available keys: ${allColumns.join(', ')}`;
    if (!yLabelKey || !allColumns.includes(yLabelKey)) return `Invalid yLabelKey: "${yLabelKey}". Available keys: ${allColumns.join(', ')}`;
    if (!chartTypes.includes(graphType)) return `Invalid graphType: ${graphType}`;
    if (typeof aggregator !== 'function' && !aggregators[aggregator]) return `Invalid aggregator: ${aggregator}`;
    return null;
  }, [data, xLabelKey, yLabelKey, graphType, aggregator, allColumns, loading, error]);


  // --- Data Filtering (based on context filters) ---
  const filteredData = useMemo(() => {
    if (!data || data.length === 0) return [];
    return data.filter((item) =>
      Object.entries(filters).every(([key, filterValue]) => {
        if (!filterValue) return true; // No filter applied for this key
        const itemValue = item[key];
        // Basic case-insensitive string check
        return itemValue !== null && itemValue !== undefined &&
               itemValue.toString().toLowerCase().includes(filterValue.toLowerCase());
        // Add more sophisticated filtering logic if needed (ranges, dates, etc.)
      })
    );
  }, [data, filters]);

  // --- Data Processing (Memoized) ---
  const processedChartData = useMemo<ChartData<any>>(() => {
    if (validationError || filteredData.length === 0) return { labels: [], datasets: [] };

    const aggFn = typeof aggregator === 'function' ? aggregator : aggregators[aggregator];
    const groupedData = groupByKeys(filteredData, selectedGroupBy);

    let labels: string[] = [];
    const datasets: any[] = []; // Keep 'any' for flexibility with different chart types
    const datasetLabels = Object.keys(groupedData); // Labels for legend/datasets

    // Determine unique X-axis labels across all groups
    labels = [...new Set(filteredData.map(item => item[xLabelKey]?.toString() ?? 'Unknown'))].sort();

    // Handle different chart type structures
    switch (graphType) {
      case 'pie':
      case 'doughnut':
      case 'polarArea':
        // For these, labels are the group names, data is aggregated value per group
        labels = datasetLabels.map(k => k.replace(/ \| /g, ' - ')); // Prettier labels
        const pieData = datasetLabels.map(groupKey => aggFn(groupedData[groupKey], yLabelKey));
        datasets.push({
          label: yLabelKey, // Often dataset label isn't prominent in pie charts
          data: pieData,
          backgroundColor: colors.slice(0, labels.length).map((c, i) => visibleDatasets[labels[i]] === false ? 'transparent' : c), // Basic visibility handling
          borderColor: colors.slice(0, labels.length).map(c => c.replace(/,(?=[^,]*$)/, ', 1')), // Make border opaque
          borderWidth: 1,
          // Pie/Doughnut visibility is often handled differently (e.g., filtering data)
          // Hiding slices via legend might need custom legend logic or data filtering
        });
        break;

      case 'bubble':
      case 'scatter':
        // Expects { x, y, r } for bubble, { x, y } for scatter
        // Grouping might represent different series here
        datasetLabels.forEach((groupKey, index) => {
          const groupItems = groupedData[groupKey];
          const pointData = groupItems.map(item => ({
            x: Number(item[xLabelKey]) || 0, // Ensure numeric X
            y: Number(item[yLabelKey]) || 0, // Ensure numeric Y
            ...(graphType === 'bubble' && { r: Math.max(5, (Number(item[yLabelKey]) || 0) / 5) }) // Example radius scaling for bubble
          }));
          datasets.push({
            label: groupKey.replace(/ \| /g, ' - '),
            data: pointData,
            backgroundColor: colors[index % colors.length],
            borderColor: colors[index % colors.length].replace(/,(?=[^,]*$)/, ', 1'),
            hidden: visibleDatasets[groupKey] === false,
          });
        });
        // For scatter/bubble, labels aren't typically categories, so clear them
        labels = [];
        break;

      case 'radar':
        // Labels are categories (xLabelKey), datasets are groups
        datasetLabels.forEach((groupKey, index) => {
          const groupItems = groupedData[groupKey];
          const radarData = labels.map(label => {
            // Find items matching the current label within the group and aggregate
            const itemsForLabel = groupItems.filter(item => (item[xLabelKey]?.toString() ?? 'Unknown') === label);
            return aggFn(itemsForLabel, yLabelKey);
          });
          datasets.push({
            label: groupKey.replace(/ \| /g, ' - '),
            data: radarData,
            backgroundColor: colors[index % colors.length].replace(/,(?=[^,]*$)/, ', 0.2)'), // Transparent fill
            borderColor: colors[index % colors.length].replace(/,(?=[^,]*$)/, ', 1'),
            borderWidth: 1,
            pointBackgroundColor: colors[index % colors.length],
            hidden: visibleDatasets[groupKey] === false,
          });
        });
        break;

      // Handle Bar, Line, Area, Stacked variations
      case 'bar':
      case 'line':
      case 'area':
      case 'stackedBar':
      case 'stackedArea':
      case 'horizontalBar':
      default: // Default handles bar, line, etc.
        const isStacked = graphType.includes('stacked');
        const isArea = graphType.includes('area');

        datasetLabels.forEach((groupKey, index) => {
          const groupItems = groupedData[groupKey];
          const seriesData = labels.map(label => {
            const itemsForLabel = groupItems.filter(item => (item[xLabelKey]?.toString() ?? 'Unknown') === label);
            return aggFn(itemsForLabel, yLabelKey);
          });
          datasets.push({
            label: groupKey.replace(/ \| /g, ' - '),
            data: seriesData,
            backgroundColor: colors[index % colors.length],
            borderColor: colors[index % colors.length].replace(/,(?=[^,]*$)/, ', 1'),
            borderWidth: graphType === 'line' || isArea ? 2 : 1,
            fill: isArea, // Fill only for area charts
            stack: isStacked ? 'stack' : undefined, // Apply stack group if needed
            hidden: visibleDatasets[groupKey] === false,
            type: graphType === 'line' || isArea ? 'line' : 'bar', // Set type for potential mixed charts later
          });
        });
        break;
    }

    return { labels, datasets };

  }, [filteredData, xLabelKey, yLabelKey, selectedGroupBy, graphType, colors, aggregator, visibleDatasets, validationError]);


 // --- Chart Options (Memoized) ---
  const chartOptions = useMemo<ChartOptions<any>>(() => {
    const isHorizontal = graphType === 'horizontalBar';
    const baseOptions: ChartOptions<any> = {
      responsive: true,
      maintainAspectRatio: false, // Important for fixed height container
      interaction: { // Improve tooltip behavior
        mode: 'index' as InteractionMode,
        intersect: false,
      },
      plugins: {
        title: { // Use the title plugin
          display: !!title,
          text: title,
          font: { size: 16 }
        },
        legend: {
          position: 'top',
          labels: { padding: 20 }, // Add padding
          onClick: (e: ChartEvent, legendItem: LegendItem, legend: LegendElement<ChartType>) => {
            // Update our visibility state based on the clicked item
            const index = legendItem.datasetIndex;
            // Ensure index is a valid number before proceeding
            if (typeof index === 'number') {
                const currentVisibility = legend.chart.isDatasetVisible(index);
                legend.chart.setDatasetVisibility(index, !currentVisibility);
                legend.chart.update();

                // Also update our React state if needed for other logic
                 const label = legendItem.text;
                 setVisibleDatasets(prev => ({ ...prev, [label]: !currentVisibility })); // Update based on new visibility
            } else {
                console.warn("Legend item clicked without a valid datasetIndex:", legendItem);
            }
          },
        },
        tooltip: {
          enabled: true,
          // Consider adding custom tooltip callbacks for better formatting
        },
      },
      // Conditionally set indexAxis for horizontal bars
      indexAxis: isHorizontal ? 'y' : 'x',
      scales: {
        // Configure X axis
        x: {
          display: graphType !== 'pie' && graphType !== 'doughnut' && graphType !== 'polarArea' && graphType !== 'radar', // Hide for circular/radar
          title: {
            display: !isHorizontal, // Display only if not horizontal bar
            text: isHorizontal ? yLabelKey : xLabelKey, // Swap labels for horizontal
            font: { size: 14 },
          },
          stacked: graphType === 'stackedBar' || graphType === 'stackedArea',
          grid: { // Subtle grid lines
              color: '#e0e0e0',
              drawOnChartArea: !isHorizontal, // Only draw grid for primary value axis
          },
          ticks: { color: '#333' }
        },
        // Configure Y axis
        y: {
          display: graphType !== 'pie' && graphType !== 'doughnut' && graphType !== 'polarArea' && graphType !== 'radar',
          title: {
            display: true,
            text: isHorizontal ? xLabelKey : yLabelKey, // Swap labels for horizontal
            font: { size: 14 }
          },
          beginAtZero: true,
          stacked: graphType === 'stackedBar' || graphType === 'stackedArea',
          grid: {
              color: '#e0e0e0',
               drawOnChartArea: isHorizontal, // Only draw grid for primary value axis
          },
           ticks: { color: '#333' }
        },
        // Configure Radial axis (for Radar, PolarArea)
        r: {
           display: graphType === 'radar' || graphType === 'polarArea',
           beginAtZero: true,
           title: { display: true, text: yLabelKey },
           grid: { color: '#e0e0e0' },
           pointLabels: { font: { size: 12 } }, // Style radar labels
           ticks: {
             backdropColor: 'rgba(255, 255, 255, 0.75)' // Make ticks readable over lines
           }
        }
      },
      // Allow overriding with custom options
      ...customOptions,
      // NOTE: Merging plugins needs to happen *after* baseOptions is defined
      // to avoid duplicate keys in the object literal.
    };

     // Merge custom plugins correctly
    if (customOptions.plugins) {
      baseOptions.plugins = {
        ...baseOptions.plugins, // Keep base plugins
        ...customOptions.plugins, // Add/override with custom plugins
      };
    }


    // Specific tweaks for certain chart types
    if (graphType === 'pie' || graphType === 'doughnut' || graphType === 'polarArea') {
         // No axes needed
    }
    if (graphType === 'bubble' || graphType === 'scatter') {
        // Ensure linear scales for x/y if not overridden
        baseOptions.scales.x.type = 'linear';
        baseOptions.scales.y.type = 'linear';
    }


    return baseOptions;
  }, [graphType, xLabelKey, yLabelKey, title, customOptions, visibleDatasets]); // Recompute if visibility changes for potential dynamic options


  // --- Event Handlers ---
  const handleChartClick = useCallback((event: MouseEvent<HTMLCanvasElement>) => { // Use React's MouseEvent
    if (!chartRef.current || !onChartClick) return;
    // Pass the React event to getElementAtEvent
    const elements = getElementAtEvent(chartRef.current, event);
    // Pass the original React event and the found elements to the callback
    // Note: The original ChartEvent is not directly available here.
    // If the consumer *needs* the ChartEvent properties (like native event),
    // this approach might need adjustment or a different event listener setup.
    onChartClick(event as unknown as ChartEvent, elements, chartRef.current); // Cast for now, review if ChartEvent needed
  }, [onChartClick]);

  if (loading) return <div className={styles.loading}>Loading Chart...</div>;
  if (error) return <div className={styles.errorMessage} role="alert">Error loading chart: {error}</div>;
  if (validationError) return <div className={styles.errorMessage} role="alert">Chart Configuration Error: {validationError}</div>;
  if (!data || data.length === 0) return <div className={styles.errorMessage} role="alert">No data available</div>;


  const exportChart = useCallback(() => {
    if (chartRef.current) {
      try {
        const url = chartRef.current.toBase64Image('image/png', 1); // Ensure quality
        const link = document.createElement('a');
        link.href = url;
        link.download = `${title || graphType}-chart.png`;
        document.body.appendChild(link); // Required for Firefox
        link.click();
        document.body.removeChild(link); // Clean up
      } catch (err) {
        console.error('Chart export failed:', err);
        // Optionally show a user-facing error message
      }
    }
  }, [graphType, title]);

  // --- Rendering ---
  if (loading) return <div className={styles.loading}>Loading Chart Data...</div>;
  if (error) return <div className={styles.errorMessage} role="alert">Error loading chart: {error}</div>;
  if (validationError) return <div className={styles.errorMessage} role="alert">Chart Configuration Error: {validationError}</div>;


  // Determine the Chart.js type based on our simplified type
  const getChartJsType = (): ChartType => {
      switch(graphType) {
          case 'stackedBar':
          case 'horizontalBar': return 'bar';
          case 'area':
          case 'stackedArea': return 'line';
          // Add other mappings if needed (e.g., if you had 'funnel' map to 'bar')
          default: return graphType as ChartType; // Cast directly for matching types
      }
  }

  return (
    <div className={styles.graphContainer}>
      {/* Controls could be moved to a separate component */}
      <div className={styles.controlGroup} role="toolbar" aria-label="Chart Controls">
         <div className={styles.controlItem}>
            <label htmlFor="chartTypeSelect">Chart Type:</label>
            <select
              id="chartTypeSelect"
              className={styles.chartTypeSelect}
              value={graphType}
              onChange={(e) => setGraphType(e.target.value as SupportedChartType)}
              aria-label="Select chart type"
            >
              {chartTypes.map((type) => (
                <option key={type} value={type}>
                  {/* Simple capitalization */}
                  {type.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase())}
                </option>
              ))}
            </select>
         </div>
         {/* Group By and Filter controls are now expected in DataTable or a dedicated Control Panel */}
         <div className={styles.controlItem}>
             {/* Empty div for grid alignment or add other controls */}
         </div>
         <div className={styles.controlItem}>
              {/* Empty div for grid alignment */}
         </div>
          <div className={styles.controlItem}>
            <label htmlFor='exportChartButton'>Actions:</label>
             <button
               id="exportChartButton"
               className={styles.exportButton}
               onClick={exportChart}
               disabled={!chartRef.current || processedChartData.datasets.length === 0}
               aria-label="Export chart as PNG"
             >
               Export PNG
             </button>
          </div>
      </div>

      <div className={styles.chartArea} role="region" aria-label={`Chart: ${title || `${yLabelKey} by ${xLabelKey}`}`}>
        <Chart
          ref={chartRef}
          type={getChartJsType()} // Use the mapped type
          data={processedChartData}
          options={chartOptions}
          onClick={handleChartClick} // Pass the updated handler
          aria-label={title || `Chart displaying ${yLabelKey} based on ${xLabelKey}`} // Duplicate for screen readers? Check best practice.
        />
      </div>
    </div>
  );
};

export default GenericGraph;
