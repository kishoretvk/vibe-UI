import React, { useContext } from 'react';
import GenericGraph from './components/GenericGraph';
import DataTable from './components/DataTable';
import ErrorBoundary from './components/ErrorBoundary';
import { DataProvider, DataContext } from './contexts/DataContext';
import { ThemeContext } from './contexts/ThemeContext'; // Import ThemeContext
import styles from './App.module.css';

// Component to render the main content, consuming the context
const AppContent: React.FC = () => {
  const { loading, error, data } = useContext(DataContext); // Get state from context

  // Handle Loading and Error States centrally
  if (loading) {
    return <div className={styles.loadingState}>Loading Dashboard Data...</div>;
  }

  if (error) {
    // Display error prominently. ErrorBoundary will catch rendering errors within children.
    return <div className={styles.errorState} role="alert">Failed to load data: {error}</div>;
  }

  if (!data || data.length === 0) {
      return <div className={styles.loadingState}>No data available.</div>; // Or a more specific message
  }

  // Data is loaded and no errors, render the components
  return (
    <div className={styles.contentGrid}>
      <ErrorBoundary>
        <GenericGraph
          xLabelKey="category" // Pass the key name from your data
          yLabelKey="value"    // Pass the key name from your data
          title="Category Value Analysis" // Example title
          initialGraphType="bar"
          // Colors, onClick, customOptions etc. can still be passed here
          colors={['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF']}
          onChartClick={(event, elements, chart) => {
            if (elements.length > 0) {
                const { datasetIndex, index } = elements[0];
                // Access data from the chart instance if needed
                const dataPoint = chart.data.datasets[datasetIndex]?.data[index];
                const label = chart.data.labels?.[index];
                console.log('Chart clicked:', { datasetIndex, index, label, dataPoint });
                // Example: You could use this to filter the table further or show details
                // const clickedCategory = label;
                // setFilters(prev => ({ ...prev, category: clickedCategory }));
            }
          }}
          // customOptions={{ // Example custom option
          //    scales: { y: { ticks: { format: { style: 'currency', currency: 'USD' }}}}
          // }}
        />
      </ErrorBoundary>
      <ErrorBoundary>
        {/* DataTable now gets all its data/state via context */}
        <DataTable />
      </ErrorBoundary>
    </div>
  );
};


// Main App component sets up the Provider
const App: React.FC = () => {
  const { theme, toggleTheme } = useContext(ThemeContext); // Consume theme context

  return (
    // DataProvider is already wrapping this in index.tsx via ThemeProvider
    <DataProvider>
       <div className={`${styles.container} ${theme === 'dark' ? styles.darkTheme : ''}`}> {/* Apply theme class */}
         <div className={styles.header}>
           <h1 className={styles.mainTitle}>Data Load App</h1>
           <button onClick={toggleTheme} className={styles.themeToggleButton} aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} theme`}>
             {theme === 'light' ? '🌙 Dark' : '☀️ Light'}
           </button>
         </div>
        {/* AppContent will consume the context provided by DataProvider */}
        <AppContent />
      </div>
    </DataProvider>
  );
};

export default App;
