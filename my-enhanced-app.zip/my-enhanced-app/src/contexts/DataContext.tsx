import React, { createContext, useState, useEffect, useCallback, ReactNode, Dispatch, SetStateAction } from 'react';

export type DataItem = Record<string, any>;
type Filters = Record<string, string>; // Key: column name, Value: filter string
type GroupBy = string[]; // Array of column names to group by

interface IDataContext {
  data: DataItem[];
  loading: boolean;
  error: string | null;
  filters: Filters;
  groupBy: GroupBy;
  allColumns: string[]; // Keep track of all available columns
  setFilters: Dispatch<SetStateAction<Filters>>;
  setGroupBy: Dispatch<SetStateAction<GroupBy>>;
  refetchData: () => void; // Function to manually trigger refetch
}

// Provide default values matching the interface
const defaultState: IDataContext = {
  data: [],
  loading: true,
  error: null,
  filters: {},
  groupBy: [],
  allColumns: [],
  setFilters: () => {},
  setGroupBy: () => {},
  refetchData: () => {},
};

export const DataContext = createContext<IDataContext>(defaultState);

interface DataProviderProps {
  children: ReactNode;
}

const API_URL = 'http://localhost:5001/api/data'; // Your backend URL

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  const [data, setData] = useState<DataItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<Filters>({});
  const [groupBy, setGroupBy] = useState<GroupBy>([]);
  const [allColumns, setAllColumns] = useState<string[]>([]);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(API_URL);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result: DataItem[] = await response.json();
      setData(result);
      // Determine all unique columns from the fetched data
      if (result.length > 0) {
        const columns = Object.keys(result[0]);
        setAllColumns(columns);
      } else {
          setAllColumns([]);
      }
    } catch (e: any) {
      console.error("Failed to fetch data:", e);
      setError(e.message || "Failed to fetch data. Is the backend running?");
      setData([]); // Clear data on error
      setAllColumns([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]); // fetchData is memoized by useCallback

  const contextValue: IDataContext = {
    data,
    loading,
    error,
    filters,
    groupBy,
    allColumns,
    setFilters,
    setGroupBy,
    refetchData: fetchData, // Expose refetch function
  };

  return (
    <DataContext.Provider value={contextValue}>
      {children}
    </DataContext.Provider>
  );
};