from flask import Flask, jsonify
from flask_cors import CORS
import time

app = Flask(__name__)
# Allow requests from our React app's default port (and others if needed)
CORS(app, resources={r"/api/*": {"origins": "http://localhost:5173"}})

# The same mock data
mock_data = [
    {'id': 1, 'category': 'A', 'value': 30, 'region': 'North', 'department': 'Sales', 'date': '2023-01-15'},
    {'id': 2, 'category': 'B', 'value': 20, 'region': 'North', 'department': 'Tech', 'date': '2023-01-20'},
    {'id': 3, 'category': 'A', 'value': 40, 'region': 'South', 'department': 'Sales', 'date': '2023-02-10'},
    {'id': 4, 'category': 'B', 'value': 50, 'region': 'South', 'department': 'Tech', 'date': '2023-02-15'},
    {'id': 5, 'category': 'C', 'value': 10, 'region': 'North', 'department': 'Sales', 'date': '2023-03-05'},
    {'id': 6, 'category': 'C', 'value': 15, 'region': 'South', 'department': 'Marketing', 'date': '2023-03-10'},
    {'id': 7, 'category': 'A', 'value': 25, 'region': 'East', 'department': 'Tech', 'date': '2023-04-12'},
    {'id': 8, 'category': 'B', 'value': 35, 'region': 'West', 'department': 'Marketing', 'date': '2023-04-18'},
    {'id': 9, 'category': 'C', 'value': 22, 'region': 'East', 'department': 'Sales', 'date': '2023-05-20'},
    {'id': 10, 'category': 'A', 'value': 45, 'region': 'West', 'department': 'Tech', 'date': '2023-05-25'},
] * 5 # Make data a bit larger for pagination/filtering demo

@app.route('/api/data', methods=['GET'])
def get_data():
    # Simulate network delay
    time.sleep(1)
    # In a real app, you'd fetch from a database here
    return jsonify(mock_data)

if __name__ == '__main__':
    # Run on a port different from React's default (3000)
    app.run(port=5001, debug=True)
